import json

with open('gpus4_batch_16_12_layer_strategy.json', 'r') as file:
    strategy = json.load(file)
    print(strategy)

for key, val in strategy.items():
    if 'linear1' in key:
        val['DataParallel']['gather_input'] = True
        val['DataParallel']['data_parallel_input'] = False
    if 'linear2' in key:
        val['DataParallel']['split_output'] = True
        val['DataParallel']['data_parallel_input'] = False

strategy['norm']['DataParallel']['gather_input'] = True
strategy['norm']['DataParallel']['data_parallel_input'] = False
strategy['linear']['DataParallel']['gather_input'] = False

print(json.dumps(strategy, indent=4))

with open('gpus4_batch_16_12_layer_strategy.json', 'w') as file:
    json.dump(strategy, file, indent=4)
