{
    "seq.fc0": {
        "DataParallel": {
            "gather_input": false,
            "split_output": false
        },
        "ModelParallel": {
            "row_linear": false,
            "input_is_parallel": false,
            "column_linear": true,
            "gather_output": true
        }
    },
    "seq.fc1": {
        "DataParallel": {
            "gather_input": false,
            "split_output": false
        },
        "ModelParallel": {
            "row_linear": false,
            "input_is_parallel": false,
            "column_linear": true,
            "gather_output": true
        }
    },
    "seq.fc2": {
        "DataParallel": {
            "gather_input": false,
            "split_output": false
        },
        "ModelParallel": {
            "row_linear": false,
            "input_is_parallel": false,
            "column_linear": true,
            "gather_output": true
        }
    },
    "seq.fc3": {
        "DataParallel": {
            "gather_input": false,
            "split_output": false
        },
        "ModelParallel": {
            "row_linear": false,
            "input_is_parallel": false,
            "column_linear": true,
            "gather_output": true
        }
    },
    "seq.fc4": {
        "DataParallel": {
            "gather_input": false,
            "split_output": false
        },
        "ModelParallel": {
            "row_linear": false,
            "input_is_parallel": false,
            "column_linear": true,
            "gather_output": true
        }
    },
    "seq.fc5": {
        "DataParallel": {
            "gather_input": false,
            "split_output": false
        },
        "ModelParallel": {
            "row_linear": false,
            "input_is_parallel": false,
            "column_linear": true,
            "gather_output": true
        }
    },
    "seq.fc6": {
        "DataParallel": {
            "gather_input": false,
            "split_output": false
        },
        "ModelParallel": {
            "row_linear": false,
            "input_is_parallel": false,
            "column_linear": true,
            "gather_output": true
        }
    },
    "seq.fc7": {
        "DataParallel": {
            "gather_input": false,
            "split_output": false
        },
        "ModelParallel": {
            "row_linear": false,
            "input_is_parallel": false,
            "column_linear": true,
            "gather_output": true
        }
    }
}
